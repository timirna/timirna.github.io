/* Motion Curve Beta - Original Flow-style easing panel for After Effects */
(function MotionCurve(thisObj){
    var NAME='Motion Curve';
    var presets=[
      ['In Sine',[.47,0,.745,.715]],['Out Sine',[.39,.575,.565,1]],['InOut Sine',[.445,.05,.55,.95]],
      ['In Quad',[.55,.085,.68,.53]],['Out Quad',[.25,.46,.45,.94]],['InOut Quad',[.455,.03,.515,.955]],
      ['In Cubic',[.55,.055,.675,.19]],['Out Cubic',[.215,.61,.355,1]],['InOut Cubic',[.645,.045,.355,1]],
      ['In Quart',[.895,.03,.685,.22]],['Out Quart',[.165,.84,.44,1]],['InOut Quart',[.77,0,.175,1]],
      ['In Quint',[.755,.05,.855,.06]],['Out Quint',[.23,1,.32,1]],['InOut Quint',[.86,0,.07,1]],
      ['In Expo',[.95,.05,.795,.035]],['Out Expo',[.19,1,.22,1]],['InOut Expo',[1,0,0,1]],
      ['In Circ',[.6,.04,.98,.335]],['Out Circ',[.075,.82,.165,1]],['InOut Circ',[.785,.135,.15,.86]],
      ['In Back',[.6,-.28,.735,.045]],['Out Back',[.175,.885,.32,1.275]],['InOut Back',[.68,-.55,.265,1.55]],
      ['Linear',[0,0,1,1]]
    ];
    var curve=[.42,0,.58,1], mode='both';
    function clamp(v,a,b){return Math.max(a,Math.min(b,v));}
    function applyCurve(){
      var comp=app.project.activeItem;
      if(!(comp instanceof CompItem)){alert('Open a composition first.');return;}
      var props=comp.selectedProperties, count=0;
      app.beginUndoGroup(NAME);
      for(var i=0;i<props.length;i++){
        var p=props[i];
        try{
          if(p.propertyType!==PropertyType.PROPERTY||p.numKeys<2)continue;
          var ks=p.selectedKeys;if(!ks||ks.length<2)continue;
          for(var q=0;q<ks.length-1;q++){
            var k1=ks[q],k2=ks[q+1],dt=p.keyTime(k2)-p.keyTime(k1);if(dt<=0)continue;
            var v1=p.keyValue(k1),v2=p.keyValue(k2),dims=(v1 instanceof Array)?v1.length:1;
            var outArr=[],inArr=[];
            for(var d=0;d<dims;d++){
              var a=(dims===1)?v1:v1[d],b=(dims===1)?v2:v2[d],delta=b-a;
              var x1=clamp(curve[0],.001,.999),x2=clamp(curve[2],.001,.999);
              var os=(delta/dt)*(curve[1]/x1),ins=(delta/dt)*((1-curve[3])/(1-x2));
              var oi=clamp(x1*100,.1,100),ii=clamp((1-x2)*100,.1,100);
              if(mode==='in'){os=0;oi=33.333;} if(mode==='out'){ins=0;ii=33.333;}
              outArr.push(new KeyframeEase(os,oi));inArr.push(new KeyframeEase(ins,ii));
            }
            p.setInterpolationTypeAtKey(k1,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);
            p.setInterpolationTypeAtKey(k2,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);
            p.setTemporalEaseAtKey(k1,p.keyInTemporalEase(k1),outArr);
            p.setTemporalEaseAtKey(k2,inArr,p.keyOutTemporalEase(k2));count++;
          }
        }catch(e){}
      }
      app.endUndoGroup();
      alert(count?'Applied to '+count+' segment(s).':'Select at least two keyframes on one or more properties.');
    }
    function buildUI(o){
      var w=(o instanceof Panel)?o:new Window('palette',NAME,undefined,{resizeable:true});
      w.orientation='column';w.alignChildren=['fill','top'];w.margins=8;w.spacing=6;
      var title=w.add('statictext',undefined,'Motion Curve — 25 Presets');
      var values=w.add('edittext',undefined,'0.420, 0.000, 0.580, 1.000');
      values.onChange=function(){var a=values.text.split(',');if(a.length===4){for(var i=0;i<4;i++)curve[i]=parseFloat(a[i]);}};
      var grid=w.add('group');grid.orientation='row';grid.alignChildren=['fill','top'];
      var col1=grid.add('group'),col2=grid.add('group'),col3=grid.add('group');
      col1.orientation=col2.orientation=col3.orientation='column';
      for(var i=0;i<presets.length;i++){
        (function(p,idx){var parent=idx%3===0?col1:(idx%3===1?col2:col3);var b=parent.add('button',undefined,p[0]);b.preferredSize=[92,24];b.onClick=function(){curve=p[1].slice(0);values.text=curve.map(function(v){return v.toFixed(3);}).join(', ');};})(presets[i],i);
      }
      var modes=w.add('group');modes.orientation='row';
      var both=modes.add('button',undefined,'Both'),ein=modes.add('button',undefined,'Ease In'),eout=modes.add('button',undefined,'Ease Out');
      both.onClick=function(){mode='both';};ein.onClick=function(){mode='in';};eout.onClick=function(){mode='out';};
      var apply=w.add('button',undefined,'APPLY');apply.preferredSize.height=34;apply.onClick=applyCurve;
      var note=w.add('statictext',undefined,'Select 2+ keyframes, choose a preset, then Apply.',{multiline:true});
      w.onResizing=w.onResize=function(){this.layout.resize();};
      if(w instanceof Window){w.center();w.show();}else w.layout.layout(true);
      return w;
    }
    buildUI(thisObj);
})(this);
