MOTION CURVE BETA

Original Flow-style After Effects ScriptUI panel with 25 Penner-inspired cubic-bezier presets.

INSTALL
1. Close After Effects.
2. Copy “Motion Curve.jsx” into:
   Windows: Adobe After Effects/Support Files/Scripts/ScriptUI Panels/
   macOS: Adobe After Effects/Scripts/ScriptUI Panels/
3. Restart After Effects.
4. Open Window > Motion Curve.

USE
1. Select at least two keyframes on one or more properties.
2. Choose one of the 25 presets.
3. Choose Both, Ease In, or Ease Out.
4. Click APPLY.

NOTES
- This is a beta, original tool and not the commercial Flow extension.
- It applies temporal easing and does not change spatial motion paths.
- Test on a duplicate project first.
