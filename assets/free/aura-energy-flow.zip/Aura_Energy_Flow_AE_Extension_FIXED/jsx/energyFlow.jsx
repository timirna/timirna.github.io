var AuraEnergyFlow=(function(){
function getComp(){
 var c=app.project.activeItem;
 if(c && c instanceof CompItem) return c;
 if(!app.project) app.newProject();
 return app.project.items.addComp('Aura Energy Flow Comp',1920,1080,1,6,30);
}
function addGlow(layer,r){try{var g=layer.Effects.addProperty('ADBE Glow');g.property('ADBE Glow Radius').setValue(r);g.property('ADBE Glow Intensity').setValue(1.55);}catch(e){} }
function ease(prop){try{var e=new KeyframeEase(0,55); for(var i=1;i<=prop.numKeys;i++){prop.setTemporalEaseAtKey(i,[e],[e]);}}catch(err){} }
function makeLine(c,name,pts,color,delay,glow){
 var l=c.layers.addShape(); l.name=name;
 var root=l.property('ADBE Root Vectors Group'); var group=root.addProperty('ADBE Vector Group'); group.name='Energy Path';
 var vectors=group.property('ADBE Vectors Group');
 var path=vectors.addProperty('ADBE Vector Shape - Group');
 var sh=new Shape(); sh.vertices=pts; sh.closed=false; sh.inTangents=[]; sh.outTangents=[];
 for(var i=0;i<pts.length;i++){sh.inTangents.push([0,0]); sh.outTangents.push([0,0]);}
 path.property('ADBE Vector Shape').setValue(sh);
 var stroke=vectors.addProperty('ADBE Vector Graphic - Stroke');
 stroke.property('ADBE Vector Stroke Color').setValue(color); stroke.property('ADBE Vector Stroke Width').setValue(3); stroke.property('ADBE Vector Stroke Opacity').setValue(88);
 var trim=vectors.addProperty('ADBE Vector Filter - Trim');
 var st=trim.property('ADBE Vector Trim Start'), en=trim.property('ADBE Vector Trim End');
 st.setValueAtTime(delay,0); en.setValueAtTime(delay,0); en.setValueAtTime(delay+.9,100); st.setValueAtTime(delay+1.65,100); ease(st); ease(en);
 addGlow(l,glow); return l;
}
function makeParticle(c,from,to,color,delay,glow){
 var l=c.layers.addShape(); l.name='Aura subtle particle'; var root=l.property('ADBE Root Vectors Group');
 var e=root.addProperty('ADBE Vector Shape - Ellipse'); e.property('ADBE Vector Ellipse Size').setValue([6,6]);
 var f=root.addProperty('ADBE Vector Graphic - Fill'); f.property('ADBE Vector Fill Color').setValue(color); f.property('ADBE Vector Fill Opacity').setValue(82);
 var tr=l.property('ADBE Transform Group'), pos=tr.property('ADBE Position'), op=tr.property('ADBE Opacity'), sc=tr.property('ADBE Scale');
 pos.setValueAtTime(delay,from); pos.setValueAtTime(delay+1.25,to); ease(pos);
 op.setValueAtTime(delay,0); op.setValueAtTime(delay+.15,80); op.setValueAtTime(delay+1.25,0); ease(op);
 sc.setValue([70+Math.random()*60,70+Math.random()*60]); addGlow(l,glow*.55); return l;
}
function createFlow(dir,count,len,glow,particles){
 app.beginUndoGroup('Aura Energy Flow'); var c=getComp(); var cx=c.width/2, cy=c.height/2;
 var colors=[[.27,.85,1],[.45,.42,1],[.95,.32,1],[.22,1,.55],[1,.78,.18]];
 count=Math.max(1,Math.min(20,count)); particles=Math.max(0,Math.min(400,particles));
 for(var i=0;i<count;i++){
  var y=cy-(count-1)*34/2+i*34; var bend=(i-(count-1)/2)*20; var pts;
  if(dir=='centerOut') pts=[[cx,cy],[cx+len*.18,cy+bend*.25],[cx+len*.52,y+bend],[cx+len,y]];
  else pts=[[cx-len,y],[cx-len*.55,y+bend],[cx-len*.18,cy+bend*.25],[cx,cy]];
  makeLine(c,'Aura energy line '+(i+1),pts,colors[i%colors.length],i*.065,glow);
 }
 for(var p=0;p<particles;p++){
  var lane=p%count; var yy=cy-(count-1)*34/2+lane*34+(Math.random()*22-11); var from,to;
  if(dir=='centerOut'){from=[cx+Math.random()*12-6,cy+Math.random()*12-6]; to=[cx+len-(Math.random()*85),yy];}
  else{from=[cx-len+Math.random()*80,yy]; to=[cx+Math.random()*16-8,cy+Math.random()*16-8];}
  makeParticle(c,from,to,colors[p%colors.length],Math.random()*1.45,glow);
 }
 app.endUndoGroup(); return 'Created energy flow in comp: '+c.name;
}
function createAuraLogo(){
 app.beginUndoGroup('Aura Logo Glow'); var c=getComp(); var cx=c.width/2, cy=c.height/2;
 var l=c.layers.addShape(); l.name='Aura center glow'; var root=l.property('ADBE Root Vectors Group');
 var e=root.addProperty('ADBE Vector Shape - Ellipse'); e.property('ADBE Vector Ellipse Size').setValue([190,190]);
 var f=root.addProperty('ADBE Vector Graphic - Fill'); f.property('ADBE Vector Fill Color').setValue([.84,.88,1]); f.property('ADBE Vector Fill Opacity').setValue(75);
 l.property('ADBE Transform Group').property('ADBE Position').setValue([cx,cy]); addGlow(l,90);
 var ring=c.layers.addShape(); ring.name='Aura orbit ring'; var rr=ring.property('ADBE Root Vectors Group'); var re=rr.addProperty('ADBE Vector Shape - Ellipse'); re.property('ADBE Vector Ellipse Size').setValue([260,92]); var rs=rr.addProperty('ADBE Vector Graphic - Stroke'); rs.property('ADBE Vector Stroke Color').setValue([.55,.55,1]); rs.property('ADBE Vector Stroke Width').setValue(2); ring.property('ADBE Transform Group').property('ADBE Position').setValue([cx,cy]); addGlow(ring,35);
 app.endUndoGroup(); return 'Created Aura center glow.';
}
function createFullScene(dir,count,len,glow,particles){createAuraLogo(); return createFlow(dir,count,len,glow,particles);}
return{createFlow:createFlow,createAuraLogo:createAuraLogo,createFullScene:createFullScene};
})();
