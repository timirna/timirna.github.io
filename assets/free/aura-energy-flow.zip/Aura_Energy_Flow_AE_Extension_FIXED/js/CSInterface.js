var SystemPath={EXTENSION:'extension'};
function CSInterface(){}
CSInterface.prototype.evalScript=function(script,callback){
  if(window.__adobe_cep__){window.__adobe_cep__.evalScript(script,callback||function(){});}else{console.log('evalScript:',script); if(callback)callback('CEP not available');}
};
CSInterface.prototype.getSystemPath=function(pathType){
  if(window.__adobe_cep__){return window.__adobe_cep__.getSystemPath(pathType);} return '';
};
