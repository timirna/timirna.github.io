(function(){
var cs=new CSInterface(); var loaded=false;
function s(t){var el=document.getElementById('status'); if(el) el.textContent=t;}
function v(id){return document.getElementById(id).value;}
function esc(p){return String(p).replace(/\\/g,'/').replace(/"/g,'\\"');}
function loadJSX(cb){
  if(loaded){cb();return;}
  var p=cs.getSystemPath(SystemPath.EXTENSION);
  var jsx=esc(p + '/jsx/energyFlow.jsx');
  cs.evalScript('$.evalFile("'+jsx+'"); "loaded";',function(res){loaded=true; s('Script loaded.'); cb();});
}
function run(code){loadJSX(function(){s('Running...'); cs.evalScript(code,function(res){s(res&&res!=='undefined'?res:'Done.');});});}
function nums(){return [parseInt(v('lines'),10)||7, parseFloat(v('length'))||720, parseFloat(v('glow'))||38, parseInt(v('particles'),10)||90];}
window.addEventListener('load',function(){
  document.getElementById('btnFlow').addEventListener('click',function(){var n=nums(); run('AuraEnergyFlow.createFlow("'+v('dir')+'",'+n[0]+','+n[1]+','+n[2]+','+n[3]+')');});
  document.getElementById('btnLogo').addEventListener('click',function(){run('AuraEnergyFlow.createAuraLogo()');});
  document.getElementById('btnFull').addEventListener('click',function(){var n=nums(); run('AuraEnergyFlow.createFullScene("'+v('dir')+'",'+n[0]+','+n[1]+','+n[2]+','+n[3]+')');});
  loadJSX(function(){s('Ready. Buttons should work now.');});
});
})();
