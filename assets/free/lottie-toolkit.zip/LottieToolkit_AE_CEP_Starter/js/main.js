var cs = new CSInterface();
function val(id){return document.getElementById(id).value;}
function setStatus(html){document.getElementById('status').innerHTML=html||'Done';}
function setComp(html){document.getElementById('compInfo').innerHTML=html||'';}
function safePath(p){return String(p).replace(/\\/g,'/').replace(/'/g,"\\'");}
function loadJSX(){
  var extPath = cs.getSystemPath(SystemPath.EXTENSION);
  if(!extPath){ setStatus('Open inside After Effects CEP panel.'); return; }
  cs.evalScript('$.evalFile(\''+safePath(extPath)+'/jsx/host.jsx\')', function(res){
    setStatus(res && res.indexOf('Error')>=0 ? res : 'Toolkit loaded.');
    run('compInfo', true);
  });
}
function run(cmd, silent){
  var args = {ease:val('easeInf'), amp:val('amp'), decay:val('decay'), offset:val('offset'), step:val('step')};
  cs.evalScript('LTK.'+cmd+'('+JSON.stringify(args)+')', function(res){
    if(cmd==='compInfo') setComp(res||'No comp info.');
    else setStatus(res||'Done');
  });
}
document.querySelectorAll('[data-cmd]').forEach(function(b){b.onclick=function(){run(this.getAttribute('data-cmd'));};});
loadJSX();
