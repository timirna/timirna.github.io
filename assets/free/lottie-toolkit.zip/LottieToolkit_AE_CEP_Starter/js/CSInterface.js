var SystemPath={EXTENSION:'extension'};
function CSInterface(){}
CSInterface.prototype.evalScript=function(script,callback){if(window.__adobe_cep__){window.__adobe_cep__.evalScript(script,callback||function(){});}else{console.log(script); if(callback)callback('Open inside After Effects CEP panel.');}};
CSInterface.prototype.getSystemPath=function(path){if(window.__adobe_cep__){return window.__adobe_cep__.getSystemPath(path);}return ''};
