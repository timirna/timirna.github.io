Lottie Toolkit - After Effects CEP Starter

Install:
1) Copy the whole LottieToolkit_AE_CEP_Starter folder to:
   Windows: C:\Program Files (x86)\Common Files\Adobe\CEP\extensions\
   or user path: C:\Users\YOURNAME\AppData\Roaming\Adobe\CEP\extensions\
2) Enable unsigned CEP panels for testing. Create/edit this registry key:
   HKEY_CURRENT_USER\Software\Adobe\CSXS.11  PlayerDebugMode = 1
   HKEY_CURRENT_USER\Software\Adobe\CSXS.12  PlayerDebugMode = 1
3) Restart After Effects.
4) Open: Window > Extensions (Legacy) > Lottie Toolkit.

Important:
- This is a starter extension. Test on copied AE projects first.
- For production/selling, signing with ZXPSignCMD or packaging as ZXP is recommended.
- Put more checks before destructive actions like Remove Unused.
