# Lottie Friendly Rig for After Effects

A simple dockable After Effects ScriptUI panel for creating null-based character controls that are safer for Lottie export than expression-heavy IK rigs.

## Features

- Create a null controller for every selected character layer
- Automatically parent artwork to its controller
- Parent selected layers as a simple FK chain
- Center anchor points
- Add a basic rotation test animation
- Uses standard After Effects transforms only

## Installation

### Windows
Copy `Lottie Friendly Rig.jsx` to:

`C:\Program Files\Adobe\Adobe After Effects <version>\Support Files\Scripts\ScriptUI Panels\`

### macOS
Copy it to:

`/Applications/Adobe After Effects <version>/Scripts/ScriptUI Panels/`

Restart After Effects, then open:

`Window > Lottie Friendly Rig`

## Recommended workflow for the fox character

1. Import the Illustrator file as **Composition – Retain Layer Sizes**.
2. Select the body-part layers.
3. Click **Center Anchor Points**.
4. Select one or more layers and click **Create Controllers + Parent**.
5. Build FK chains manually:
   - Hand → Forearm → Upper Arm → Body controller
   - Foot → Shin → Thigh → Body controller
   - Head → Body controller
   - Tail → Body controller
6. Animate the controller nulls with Position, Rotation, Scale, and Opacity.
7. Export with Bodymovin and test the JSON in a Lottie preview before delivery.

## Important limitation

This is a Lottie-friendly FK controller tool, not true IK. True DUIK-style IK relies on expressions and constraints that may not export reliably to Lottie. For maximum compatibility, animate the controller rotations manually and test early on Android and iOS.
