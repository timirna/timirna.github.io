/*
Lottie Friendly Rig
After Effects ScriptUI Panel
Creates simple null-based controllers and parenting without IK expressions.
Designed for Lottie-friendly workflows.

Install:
Windows:
C:\Program Files\Adobe\Adobe After Effects <version>\Support Files\Scripts\ScriptUI Panels\
macOS:
/Applications/Adobe After Effects <version>/Scripts/ScriptUI Panels/

Restart After Effects, then open:
Window > Lottie Friendly Rig
*/

(function LottieFriendlyRig(thisObj) {
    function sanitizeName(name) {
        return name.replace(/[^\w\-]+/g, "_");
    }

    function getActiveComp() {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) {
            alert("Please open or select a composition first.");
            return null;
        }
        return comp;
    }

    function getSelectedLayers(comp) {
        var layers = comp.selectedLayers;
        if (!layers || layers.length === 0) {
            alert("Select one or more character layers first.");
            return null;
        }
        return layers;
    }

    function layerWorldPosition(layer) {
        try {
            return layer.toComp(layer.anchorPoint.value);
        } catch (e) {
            return layer.position.value;
        }
    }

    function createControllerForLayer(comp, layer, suffix, controllerSize) {
        var ctrlName = sanitizeName(layer.name) + suffix;
        var ctrl = comp.layers.addNull();
        ctrl.name = ctrlName;
        ctrl.label = 10;
        ctrl.threeDLayer = layer.threeDLayer;

        if (layer.threeDLayer) {
            var p3 = layer.toWorld(layer.anchorPoint.value);
            ctrl.position.setValue(p3);
        } else {
            var p2 = layerWorldPosition(layer);
            ctrl.position.setValue([p2[0], p2[1]]);
        }

        ctrl.anchorPoint.setValue([50, 50]);
        ctrl.scale.setValue([controllerSize, controllerSize]);
        ctrl.moveBefore(layer);

        return ctrl;
    }

    function findLayerByName(comp, name) {
        for (var i = 1; i <= comp.numLayers; i++) {
            if (comp.layer(i).name === name) {
                return comp.layer(i);
            }
        }
        return null;
    }

    function createControllers(parentOriginalLayers, suffix, controllerSize) {
        var comp = getActiveComp();
        if (!comp) return;

        var selected = getSelectedLayers(comp);
        if (!selected) return;

        app.beginUndoGroup("Create Lottie Controllers");

        var created = [];
        for (var i = selected.length - 1; i >= 0; i--) {
            var layer = selected[i];
            if (layer.nullLayer) continue;

            var existing = findLayerByName(comp, sanitizeName(layer.name) + suffix);
            var ctrl = existing || createControllerForLayer(comp, layer, suffix, controllerSize);

            if (parentOriginalLayers) {
                var oldParent = layer.parent;
                layer.parent = ctrl;
                if (oldParent && oldParent !== ctrl) {
                    ctrl.parent = oldParent;
                }
            }
            created.push(ctrl);
        }

        for (var j = 1; j <= comp.numLayers; j++) {
            comp.layer(j).selected = false;
        }
        for (var k = 0; k < created.length; k++) {
            created[k].selected = true;
        }

        app.endUndoGroup();
    }

    function parentSelectedInStackOrder() {
        var comp = getActiveComp();
        if (!comp) return;

        var selected = getSelectedLayers(comp);
        if (!selected || selected.length < 2) {
            alert("Select at least two layers.\nTop selected layer becomes the child of the next selected layer.");
            return;
        }

        app.beginUndoGroup("Parent Selected Chain");

        // AE selectedLayers are returned in layer/index order.
        for (var i = 0; i < selected.length - 1; i++) {
            selected[i].parent = selected[i + 1];
        }

        app.endUndoGroup();
    }

    function parentArtworkToMatchingControllers(suffix) {
        var comp = getActiveComp();
        if (!comp) return;

        var selected = getSelectedLayers(comp);
        if (!selected) return;

        app.beginUndoGroup("Parent to Matching Controllers");

        var missing = [];
        for (var i = 0; i < selected.length; i++) {
            var layer = selected[i];
            if (layer.nullLayer) continue;

            var ctrlName = sanitizeName(layer.name) + suffix;
            var ctrl = findLayerByName(comp, ctrlName);

            if (ctrl) {
                layer.parent = ctrl;
            } else {
                missing.push(layer.name);
            }
        }

        app.endUndoGroup();

        if (missing.length > 0) {
            alert("No matching controller found for:\n\n" + missing.join("\n"));
        }
    }

    function setAnchorToCenter() {
        var comp = getActiveComp();
        if (!comp) return;

        var selected = getSelectedLayers(comp);
        if (!selected) return;

        app.beginUndoGroup("Center Anchor Points");

        for (var i = 0; i < selected.length; i++) {
            var layer = selected[i];
            if (!layer.sourceRectAtTime) continue;

            try {
                var rect = layer.sourceRectAtTime(comp.time, false);
                var oldAnchor = layer.anchorPoint.value;
                var newAnchor = [
                    rect.left + rect.width / 2,
                    rect.top + rect.height / 2
                ];

                var delta = [
                    newAnchor[0] - oldAnchor[0],
                    newAnchor[1] - oldAnchor[1]
                ];

                var oldPos = layer.position.value;
                layer.anchorPoint.setValue(newAnchor);

                if (layer.parent === null && !layer.threeDLayer) {
                    layer.position.setValue([
                        oldPos[0] + delta[0] * layer.scale.value[0] / 100,
                        oldPos[1] + delta[1] * layer.scale.value[1] / 100
                    ]);
                }
            } catch (e) {}
        }

        app.endUndoGroup();
    }

    function addBasicMotionKeys() {
        var comp = getActiveComp();
        if (!comp) return;

        var selected = getSelectedLayers(comp);
        if (!selected) return;

        var startTime = comp.time;
        var midTime = startTime + 0.25;
        var endTime = startTime + 0.5;

        app.beginUndoGroup("Add Basic Motion Keys");

        for (var i = 0; i < selected.length; i++) {
            var layer = selected[i];
            var rot = layer.property("ADBE Transform Group").property("ADBE Rotate Z");
            if (!rot) continue;

            var base = rot.value;
            rot.setValueAtTime(startTime, base);
            rot.setValueAtTime(midTime, base + 8);
            rot.setValueAtTime(endTime, base);

            var k1 = rot.nearestKeyIndex(startTime);
            var k2 = rot.nearestKeyIndex(midTime);
            var k3 = rot.nearestKeyIndex(endTime);

            var ease = new KeyframeEase(0, 66);
            try {
                rot.setTemporalEaseAtKey(k1, [ease], [ease]);
                rot.setTemporalEaseAtKey(k2, [ease], [ease]);
                rot.setTemporalEaseAtKey(k3, [ease], [ease]);
            } catch (e) {}
        }

        app.endUndoGroup();
    }

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", "Lottie Friendly Rig", undefined, {resizeable: true});

        if (!pal) return pal;

        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 10;

        var title = pal.add("statictext", undefined, "Lottie Friendly Rig");
        title.alignment = ["fill", "top"];

        var info = pal.add("statictext", undefined,
            "Null controllers + parenting only.\nNo IK expressions or Puppet Pins.",
            {multiline: true});
        info.alignment = ["fill", "top"];

        var settings = pal.add("panel", undefined, "Controller Settings");
        settings.orientation = "row";
        settings.alignChildren = ["left", "center"];
        settings.margins = 10;

        settings.add("statictext", undefined, "Suffix:");
        var suffixInput = settings.add("edittext", undefined, "_CTRL");
        suffixInput.characters = 8;

        settings.add("statictext", undefined, "Size:");
        var sizeInput = settings.add("edittext", undefined, "70");
        sizeInput.characters = 4;

        var createPanel = pal.add("panel", undefined, "Create");
        createPanel.orientation = "column";
        createPanel.alignChildren = ["fill", "top"];
        createPanel.margins = 10;

        var btnCreateParent = createPanel.add("button", undefined, "Create Controllers + Parent");
        var btnCreateOnly = createPanel.add("button", undefined, "Create Controllers Only");
        var btnMatch = createPanel.add("button", undefined, "Parent to Matching Controllers");

        var rigPanel = pal.add("panel", undefined, "Rig Utilities");
        rigPanel.orientation = "column";
        rigPanel.alignChildren = ["fill", "top"];
        rigPanel.margins = 10;

        var btnChain = rigPanel.add("button", undefined, "Parent Selected as Chain");
        var btnAnchor = rigPanel.add("button", undefined, "Center Anchor Points");
        var btnMotion = rigPanel.add("button", undefined, "Add Simple Rotation Test");

        var helpText = pal.add("statictext", undefined,
            "Suggested arm order for chain:\nHand → Forearm → Upper Arm → Body controller",
            {multiline: true});
        helpText.alignment = ["fill", "top"];

        function suffixValue() {
            return suffixInput.text || "_CTRL";
        }

        function sizeValue() {
            var n = parseFloat(sizeInput.text);
            return isNaN(n) ? 70 : n;
        }

        btnCreateParent.onClick = function () {
            createControllers(true, suffixValue(), sizeValue());
        };

        btnCreateOnly.onClick = function () {
            createControllers(false, suffixValue(), sizeValue());
        };

        btnMatch.onClick = function () {
            parentArtworkToMatchingControllers(suffixValue());
        };

        btnChain.onClick = function () {
            parentSelectedInStackOrder();
        };

        btnAnchor.onClick = function () {
            setAnchorToCenter();
        };

        btnMotion.onClick = function () {
            addBasicMotionKeys();
        };

        pal.onResizing = pal.onResize = function () {
            this.layout.resize();
        };

        pal.layout.layout(true);
        pal.layout.resize();

        return pal;
    }

    var panel = buildUI(thisObj);
    if (panel instanceof Window) {
        panel.center();
        panel.show();
    }
})(this);
