AE Shape to Illustrator
=======================

A dockable After Effects ScriptUI panel that exports selected shape layers as SVG
and can open the SVG directly in Adobe Illustrator.

INSTALLATION
------------

Windows:
1. Close After Effects.
2. Copy "AE Shape to Illustrator.jsx" to:
   C:\Program Files\Adobe\Adobe After Effects <version>\Support Files\Scripts\ScriptUI Panels\
3. Open After Effects.
4. Go to Edit > Preferences > Scripting & Expressions.
5. Enable "Allow Scripts to Write Files and Access Network".
6. Restart After Effects.
7. Open it from Window > AE Shape to Illustrator.

macOS:
1. Close After Effects.
2. Copy "AE Shape to Illustrator.jsx" to:
   /Applications/Adobe After Effects <version>/Scripts/ScriptUI Panels/
3. Open After Effects.
4. Go to After Effects > Settings/Preferences > Scripting & Expressions.
5. Enable "Allow Scripts to Write Files and Access Network".
6. Restart After Effects.
7. Open it from Window > AE Shape to Illustrator.

HOW TO USE
----------

1. Open a composition.
2. Select one or more shape layers.
3. Open Window > AE Shape to Illustrator.
4. Click:
   - Export SVG
   - Export + Open Illustrator
5. Save the SVG.
6. In Illustrator, use Object > Ungroup if you want separate paths.

SUPPORTED
---------

- Bezier shape paths
- Basic rectangles and ellipses
- Solid fills
- Solid strokes
- Group anchor, position, scale and rotation
- Layer transforms, flattened into composition coordinates
- Multiple selected shape layers

LIMITATIONS
-----------

For best results, convert these to ordinary paths first:
- Trim Paths
- Repeaters
- Merge Paths
- Offset Paths
- Stars and polygons
- Complex procedural operators

These may not match exactly:
- Gradients
- Dashes
- Tapered strokes
- Skew
- 3D layers
- Expressions
- Animated properties at times other than the current frame

This script exports the current appearance at the current timeline frame.
