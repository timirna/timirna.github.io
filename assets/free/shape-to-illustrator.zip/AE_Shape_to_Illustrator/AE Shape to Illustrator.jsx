/*
AE Shape to Illustrator
Dockable ScriptUI panel for Adobe After Effects.

Exports selected 2D shape layers to SVG and can open the SVG in Adobe Illustrator.

Supported:
- Bezier shape paths
- Basic rectangle and ellipse paths
- Solid fills
- Solid strokes
- Group transforms: anchor, position, scale, rotation
- Layer transforms through toComp()
- Multiple selected shape layers

Limitations:
- Convert Trim Paths, Repeaters, Merge Paths, Offset Paths and complex operators to
  ordinary paths before export.
- Gradients, dashes, tapered strokes, skew, 3D layers and expressions may not match exactly.
- For the cleanest result, use 2D shape layers and convert parametric shapes to Bezier paths.
*/

(function AE_Shape_to_Illustrator(thisObj) {
    var SCRIPT_NAME = "AE Shape to Illustrator";

    function num(v) {
        if (Math.abs(v) < 0.000001) { v = 0; }
        return Math.round(v * 1000) / 1000;
    }

    function esc(s) {
        return String(s)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;");
    }

    function rgbToHex(c) {
        function h(v) {
            var n = Math.max(0, Math.min(255, Math.round(v * 255)));
            var s = n.toString(16).toUpperCase();
            return s.length < 2 ? "0" + s : s;
        }
        return "#" + h(c[0]) + h(c[1]) + h(c[2]);
    }

    function identity() {
        return [1, 0, 0, 1, 0, 0];
    }

    function multiply(a, b) {
        return [
            a[0] * b[0] + a[2] * b[1],
            a[1] * b[0] + a[3] * b[1],
            a[0] * b[2] + a[2] * b[3],
            a[1] * b[2] + a[3] * b[3],
            a[0] * b[4] + a[2] * b[5] + a[4],
            a[1] * b[4] + a[3] * b[5] + a[5]
        ];
    }

    function translate(tx, ty) {
        return [1, 0, 0, 1, tx, ty];
    }

    function scale(sx, sy) {
        return [sx, 0, 0, sy, 0, 0];
    }

    function rotate(deg) {
        var r = deg * Math.PI / 180;
        var c = Math.cos(r), s = Math.sin(r);
        return [c, s, -s, c, 0, 0];
    }

    function applyMatrix(m, p) {
        return [
            m[0] * p[0] + m[2] * p[1] + m[4],
            m[1] * p[0] + m[3] * p[1] + m[5]
        ];
    }

    function propValue(group, matchName, fallback) {
        var p = group.property(matchName);
        return p ? p.value : fallback;
    }

    function vectorTransformMatrix(group) {
        var t = group.property("ADBE Vector Transform Group");
        if (!t) { return identity(); }

        var anchor = propValue(t, "ADBE Vector Anchor", [0, 0]);
        var pos = propValue(t, "ADBE Vector Position", [0, 0]);
        var scl = propValue(t, "ADBE Vector Scale", [100, 100]);
        var rot = propValue(t, "ADBE Vector Rotation", 0);

        var m = identity();
        m = multiply(m, translate(pos[0], pos[1]));
        m = multiply(m, rotate(rot));
        m = multiply(m, scale(scl[0] / 100, scl[1] / 100));
        m = multiply(m, translate(-anchor[0], -anchor[1]));
        return m;
    }

    function pointToComp(layer, groupMatrix, p) {
        var local = applyMatrix(groupMatrix, p);
        var cp = layer.toComp([local[0], local[1], 0]);
        return [cp[0], cp[1]];
    }

    function pathDataFromShape(layer, shape, groupMatrix) {
        var verts = shape.vertices;
        var ins = shape.inTangents;
        var outs = shape.outTangents;
        var closed = shape.closed;
        if (!verts || verts.length === 0) { return ""; }

        var p0 = pointToComp(layer, groupMatrix, verts[0]);
        var d = "M " + num(p0[0]) + " " + num(p0[1]);

        var last = closed ? verts.length : verts.length - 1;
        for (var i = 0; i < last; i++) {
            var j = (i + 1) % verts.length;

            var c1local = [
                verts[i][0] + outs[i][0],
                verts[i][1] + outs[i][1]
            ];
            var c2local = [
                verts[j][0] + ins[j][0],
                verts[j][1] + ins[j][1]
            ];

            var c1 = pointToComp(layer, groupMatrix, c1local);
            var c2 = pointToComp(layer, groupMatrix, c2local);
            var p = pointToComp(layer, groupMatrix, verts[j]);

            var straight =
                Math.abs(outs[i][0]) < 0.00001 &&
                Math.abs(outs[i][1]) < 0.00001 &&
                Math.abs(ins[j][0]) < 0.00001 &&
                Math.abs(ins[j][1]) < 0.00001;

            if (straight) {
                d += " L " + num(p[0]) + " " + num(p[1]);
            } else {
                d += " C " +
                    num(c1[0]) + " " + num(c1[1]) + " " +
                    num(c2[0]) + " " + num(c2[1]) + " " +
                    num(p[0]) + " " + num(p[1]);
            }
        }

        if (closed) { d += " Z"; }
        return d;
    }

    function ellipseShape(size, pos) {
        var rx = size[0] / 2, ry = size[1] / 2;
        var k = 0.5522847498307936;
        return {
            vertices: [
                [pos[0], pos[1] - ry],
                [pos[0] + rx, pos[1]],
                [pos[0], pos[1] + ry],
                [pos[0] - rx, pos[1]]
            ],
            inTangents: [
                [-k * rx, 0],
                [0, -k * ry],
                [k * rx, 0],
                [0, k * ry]
            ],
            outTangents: [
                [k * rx, 0],
                [0, k * ry],
                [-k * rx, 0],
                [0, -k * ry]
            ],
            closed: true
        };
    }

    function rectShape(size, pos, roundness) {
        var w = size[0] / 2, h = size[1] / 2;
        var r = Math.max(0, Math.min(roundness || 0, Math.min(w, h)));
        if (r <= 0.001) {
            return {
                vertices: [
                    [pos[0] - w, pos[1] - h],
                    [pos[0] + w, pos[1] - h],
                    [pos[0] + w, pos[1] + h],
                    [pos[0] - w, pos[1] + h]
                ],
                inTangents: [[0,0],[0,0],[0,0],[0,0]],
                outTangents: [[0,0],[0,0],[0,0],[0,0]],
                closed: true
            };
        }

        var k = 0.5522847498307936;
        return {
            vertices: [
                [pos[0] - w + r, pos[1] - h],
                [pos[0] + w - r, pos[1] - h],
                [pos[0] + w, pos[1] - h + r],
                [pos[0] + w, pos[1] + h - r],
                [pos[0] + w - r, pos[1] + h],
                [pos[0] - w + r, pos[1] + h],
                [pos[0] - w, pos[1] + h - r],
                [pos[0] - w, pos[1] - h + r]
            ],
            inTangents: [
                [-k*r,0],[0,0],[0,-k*r],[0,0],[k*r,0],[0,0],[0,k*r],[0,0]
            ],
            outTangents: [
                [0,0],[k*r,0],[0,0],[0,k*r],[0,0],[-k*r,0],[0,0],[0,-k*r]
            ],
            closed: true
        };
    }

    function getStyle(contents, inherited) {
        var style = {
            fill: inherited.fill,
            fillOpacity: inherited.fillOpacity,
            stroke: inherited.stroke,
            strokeOpacity: inherited.strokeOpacity,
            strokeWidth: inherited.strokeWidth
        };

        for (var i = 1; i <= contents.numProperties; i++) {
            var p = contents.property(i);
            if (!p || p.enabled === false) { continue; }

            if (p.matchName === "ADBE Vector Graphic - Fill") {
                var col = p.property("ADBE Vector Fill Color");
                var op = p.property("ADBE Vector Fill Opacity");
                style.fill = col ? rgbToHex(col.value) : "#000000";
                style.fillOpacity = op ? op.value / 100 : 1;
            } else if (p.matchName === "ADBE Vector Graphic - Stroke") {
                var scol = p.property("ADBE Vector Stroke Color");
                var sop = p.property("ADBE Vector Stroke Opacity");
                var sw = p.property("ADBE Vector Stroke Width");
                style.stroke = scol ? rgbToHex(scol.value) : "#000000";
                style.strokeOpacity = sop ? sop.value / 100 : 1;
                style.strokeWidth = sw ? sw.value : 1;
            }
        }
        return style;
    }

    function styleAttrs(style) {
        var s = "";
        s += ' fill="' + (style.fill || "none") + '"';
        if (style.fill && style.fill !== "none") {
            s += ' fill-opacity="' + num(style.fillOpacity) + '"';
        }
        s += ' stroke="' + (style.stroke || "none") + '"';
        if (style.stroke && style.stroke !== "none") {
            s += ' stroke-opacity="' + num(style.strokeOpacity) + '"';
            s += ' stroke-width="' + num(style.strokeWidth) + '"';
            s += ' stroke-linecap="round" stroke-linejoin="round"';
        }
        return s;
    }

    function collectContents(layer, contents, parentMatrix, inheritedStyle, out, warnings) {
        var style = getStyle(contents, inheritedStyle);

        for (var i = 1; i <= contents.numProperties; i++) {
            var p = contents.property(i);
            if (!p || p.enabled === false) { continue; }

            if (p.matchName === "ADBE Vector Group") {
                var childContents = p.property("ADBE Vectors Group");
                var childMatrix = multiply(parentMatrix, vectorTransformMatrix(p));
                collectContents(layer, childContents, childMatrix, style, out, warnings);

            } else if (p.matchName === "ADBE Vector Shape - Group") {
                var pathProp = p.property("ADBE Vector Shape");
                if (pathProp) {
                    var d = pathDataFromShape(layer, pathProp.value, parentMatrix);
                    if (d) {
                        out.push('<path d="' + d + '"' + styleAttrs(style) + '/>');
                    }
                }

            } else if (p.matchName === "ADBE Vector Shape - Ellipse") {
                var es = p.property("ADBE Vector Ellipse Size");
                var ep = p.property("ADBE Vector Ellipse Position");
                if (es && ep) {
                    var eShape = ellipseShape(es.value, ep.value);
                    var ed = pathDataFromShape(layer, eShape, parentMatrix);
                    out.push('<path d="' + ed + '"' + styleAttrs(style) + '/>');
                }

            } else if (p.matchName === "ADBE Vector Shape - Rect") {
                var rs = p.property("ADBE Vector Rect Size");
                var rp = p.property("ADBE Vector Rect Position");
                var rr = p.property("ADBE Vector Rect Roundness");
                if (rs && rp) {
                    var rShape = rectShape(rs.value, rp.value, rr ? rr.value : 0);
                    var rd = pathDataFromShape(layer, rShape, parentMatrix);
                    out.push('<path d="' + rd + '"' + styleAttrs(style) + '/>');
                }

            } else if (
                p.matchName === "ADBE Vector Filter - Trim" ||
                p.matchName === "ADBE Vector Filter - Repeater" ||
                p.matchName === "ADBE Vector Filter - Merge" ||
                p.matchName === "ADBE Vector Filter - Offset" ||
                p.matchName === "ADBE Vector Filter - RC" ||
                p.matchName === "ADBE Vector Filter - PB"
            ) {
                warnings.push("Unsupported shape operator found in “" + layer.name + "”. Convert it to paths before export.");
            }
        }
    }

    function exportSVG(openInIllustrator) {
        var comp = app.project.activeItem;
        if (!(comp instanceof CompItem)) {
            alert("Open a composition first.");
            return;
        }

        var layers = comp.selectedLayers;
        if (!layers || layers.length === 0) {
            alert("Select one or more shape layers.");
            return;
        }

        var output = [];
        var warnings = [];
        var found = 0;
        var baseStyle = {
            fill: "none",
            fillOpacity: 1,
            stroke: "none",
            strokeOpacity: 1,
            strokeWidth: 1
        };

        for (var i = layers.length - 1; i >= 0; i--) {
            var layer = layers[i];
            if (layer.matchName !== "ADBE Vector Layer") {
                warnings.push("Skipped non-shape layer: " + layer.name);
                continue;
            }
            if (layer.threeDLayer) {
                warnings.push("3D layer exported as a flattened 2D view: " + layer.name);
            }

            var contents = layer.property("ADBE Root Vectors Group");
            if (!contents) { continue; }

            var parts = [];
            collectContents(layer, contents, identity(), baseStyle, parts, warnings);
            if (parts.length > 0) {
                found++;
                output.push('<g id="' + esc(layer.name) + '">');
                for (var j = 0; j < parts.length; j++) { output.push(parts[j]); }
                output.push('</g>');
            }
        }

        if (found === 0) {
            alert("No supported shape paths were found.");
            return;
        }

        var file = File.saveDialog("Export selected shape layers as SVG", "SVG:*.svg");
        if (!file) { return; }
        if (!/\.svg$/i.test(file.name)) {
            file = new File(file.fsName + ".svg");
        }

        var svg = [];
        svg.push('<?xml version="1.0" encoding="UTF-8"?>');
        svg.push('<svg xmlns="http://www.w3.org/2000/svg" width="' + comp.width +
            '" height="' + comp.height + '" viewBox="0 0 ' + comp.width + ' ' + comp.height + '">');
        svg.push('<title>' + esc(comp.name) + '</title>');
        for (var k = 0; k < output.length; k++) { svg.push(output[k]); }
        svg.push('</svg>');

        file.encoding = "UTF-8";
        if (!file.open("w")) {
            alert("Could not write the SVG file.");
            return;
        }
        file.write(svg.join("\n"));
        file.close();

        if (openInIllustrator) {
            try {
                if (typeof BridgeTalk !== "undefined" && BridgeTalk.isRunning("illustrator")) {
                    var bt = new BridgeTalk();
                    bt.target = "illustrator";
                    bt.body = 'app.open(new File("' + file.fsName.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"));';
                    bt.send();
                } else {
                    var bt2 = new BridgeTalk();
                    bt2.target = "illustrator";
                    bt2.body = 'app.open(new File("' + file.fsName.replace(/\\/g, "\\\\").replace(/"/g, '\\"') + '"));';
                    bt2.send();
                }
            } catch (e) {
                file.execute();
            }
        }

        var msg = "SVG exported successfully:\n" + file.fsName;
        if (warnings.length > 0) {
            msg += "\n\nNotes:\n- " + warnings.join("\n- ");
        }
        alert(msg);
    }

    function showHelp() {
        alert(
            SCRIPT_NAME + "\n\n" +
            "1. Select one or more 2D shape layers.\n" +
            "2. Click Export SVG or Export + Open Illustrator.\n" +
            "3. Choose where to save the SVG.\n\n" +
            "Best results:\n" +
            "• Convert complex shape operators to paths.\n" +
            "• Convert stars and polygons to Bezier paths.\n" +
            "• Use solid fills and strokes.\n" +
            "• Keep layers 2D."
        );
    }

    function buildUI(thisObj) {
        var pal = (thisObj instanceof Panel)
            ? thisObj
            : new Window("palette", SCRIPT_NAME, undefined, {resizeable: true});

        if (!pal) { return pal; }

        pal.orientation = "column";
        pal.alignChildren = ["fill", "top"];
        pal.spacing = 8;
        pal.margins = 12;

        var title = pal.add("statictext", undefined, "AE Shape → Illustrator");
        title.alignment = ["fill", "top"];

        var desc = pal.add("statictext", undefined, "Export selected shape layers as editable SVG.", {multiline: true});
        desc.alignment = ["fill", "top"];

        var exportBtn = pal.add("button", undefined, "Export SVG");
        var openBtn = pal.add("button", undefined, "Export + Open Illustrator");
        var helpBtn = pal.add("button", undefined, "Help / Limitations");

        exportBtn.onClick = function () { exportSVG(false); };
        openBtn.onClick = function () { exportSVG(true); };
        helpBtn.onClick = showHelp;

        pal.onResizing = pal.onResize = function () { this.layout.resize(); };

        if (pal instanceof Window) {
            pal.center();
            pal.show();
        } else {
            pal.layout.layout(true);
        }
        return pal;
    }

    buildUI(thisObj);

})(this);
