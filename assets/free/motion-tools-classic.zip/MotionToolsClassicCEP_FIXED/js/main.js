function $(id){ return document.getElementById(id); }
function val(id){ return $(id).value; }
function statusMsg(t){ $("status").innerHTML = t; }

function evalAE(code){
  try{
    if(window.__adobe_cep__ && window.__adobe_cep__.evalScript){
      window.__adobe_cep__.evalScript(code, function(result){
        statusMsg(result && result.length ? result : "Done");
      });
    }else{
      alert("CEP bridge not available. Open this from After Effects: Window > Extensions > Motion Tools Classic Fixed");
    }
  }catch(err){
    alert("Extension error: " + err.toString());
  }
}

function sync(rangeId, inputId){
  var r=$(rangeId), i=$(inputId);
  r.oninput=function(){i.value=this.value};
  i.onchange=function(){r.value=this.value};
}
sync("amountRange","amount");
sync("durRange","duration");
sync("delayRange","delay");

document.querySelectorAll("[data-ease]").forEach(function(btn){
  btn.addEventListener("click", function(){
    evalAE("easeSelected('" + this.getAttribute("data-ease") + "')");
  });
});

document.querySelectorAll("[data-pop]").forEach(function(btn){
  btn.addEventListener("click", function(){
    var type=this.getAttribute("data-pop");
    evalAE("applyPop('" + type + "'," + val("amount") + "," + val("duration") + "," + val("delay") + ")");
  });
});

document.querySelectorAll("[data-host]").forEach(function(btn){
  btn.addEventListener("click", function(){
    evalAE(this.getAttribute("data-host"));
  });
});

$("sequenceBtn").addEventListener("click", function(){
  evalAE("sequenceLayers(" + val("offset") + "," + val("step") + ")");
});

document.querySelectorAll(".gridBtns button").forEach(function(btn){
  btn.addEventListener("click", function(){
    document.querySelectorAll(".gridBtns button").forEach(function(b){b.classList.remove("active")});
    this.classList.add("active");
  });
});
