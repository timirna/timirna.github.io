function mtResult(msg){ return msg; }

function getComp(){
    var comp = app.project.activeItem;
    if (!(comp instanceof CompItem)) {
        alert("Please open a composition first.");
        return null;
    }
    return comp;
}

function mtScaleValue(prop, v){
    try {
        if (prop.value.length === 3) return [v,v,v];
    } catch(e) {}
    return [v,v];
}

function mtEaseArrays(prop, influenceIn, influenceOut){
    var dims = 1;
    try { if (prop.value instanceof Array) dims = prop.value.length; } catch(e){}
    var easeIn = [], easeOut = [];
    for (var i=0; i<dims; i++){
        easeIn.push(new KeyframeEase(0, influenceIn));
        easeOut.push(new KeyframeEase(0, influenceOut));
    }
    return {easeIn:easeIn, easeOut:easeOut};
}

function mtSetEase(prop, k, inInf, outInf){
    try {
        var e = mtEaseArrays(prop, inInf, outInf);
        prop.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
        prop.setTemporalEaseAtKey(k, e.easeIn, e.easeOut);
    } catch(err) {}
}

function mtApplyEaseMode(prop, k, mode){
    var inInf = 70, outInf = 70;
    if(mode === "smooth"){ inInf = 75; outInf = 75; }
    if(mode === "fastin"){ inInf = 90; outInf = 20; }
    if(mode === "fastout"){ inInf = 20; outInf = 90; }
    if(mode === "slowin"){ inInf = 25; outInf = 85; }
    if(mode === "slowout"){ inInf = 85; outInf = 25; }
    mtSetEase(prop, k, inInf, outInf);
}

function mtSelectedProps(layer){
    var props = [];
    function scan(group){
        if(!group || !group.numProperties) return;
        for (var i=1; i<=group.numProperties; i++){
            var p = group.property(i);
            try {
                if (p.selected && p.numKeys && p.numKeys > 0) props.push(p);
            } catch(e){}
            try {
                if (p.numProperties && p.numProperties > 0) scan(p);
            } catch(e){}
        }
    }
    scan(layer);
    return props;
}

function easeSelected(mode){
    var comp = getComp(); if(!comp) return "No comp";
    if(comp.selectedLayers.length === 0){ alert("Select layers or keyframes first."); return "Select layers"; }

    app.beginUndoGroup("Motion Tools Ease " + mode);

    for(var i=0; i<comp.selectedLayers.length; i++){
        var layer = comp.selectedLayers[i];
        var props = mtSelectedProps(layer);

        if(props.length === 0){
            var tr = layer.property("ADBE Transform Group");
            props = [
                tr.property("ADBE Position"),
                tr.property("ADBE Scale"),
                tr.property("ADBE Rotate Z"),
                tr.property("ADBE Opacity")
            ];
        }

        for(var p=0; p<props.length; p++){
            var prop = props[p];
            if(!prop) continue;
            var nk = 0;
            try { nk = prop.numKeys; } catch(e) { nk = 0; }
            if(nk === 0) continue;

            var usedSelected = false;
            for(var k=1; k<=nk; k++){
                try {
                    if(prop.keySelected(k)){
                        mtApplyEaseMode(prop, k, mode);
                        usedSelected = true;
                    }
                } catch(e){}
            }
            if(!usedSelected){
                for(var kk=1; kk<=nk; kk++) mtApplyEaseMode(prop, kk, mode);
            }
        }
    }

    app.endUndoGroup();
    return "Ease applied: " + mode;
}

function applyPop(type, amount, duration, delay){
    var comp = getComp(); if(!comp) return "No comp";
    if(comp.selectedLayers.length === 0){ alert("Select at least one layer."); return "Select layers"; }

    amount = parseFloat(amount); duration = parseFloat(duration); delay = parseFloat(delay);
    if(isNaN(amount)) amount = 35;
    if(isNaN(duration)) duration = 0.35;
    if(isNaN(delay)) delay = 0;

    app.beginUndoGroup("Motion Tools Pop " + type);

    var selected = comp.selectedLayers;
    for(var i=0; i<selected.length; i++){
        var layer = selected[i];
        var tr = layer.property("ADBE Transform Group");
        var scale = tr.property("ADBE Scale");
        var opacity = tr.property("ADBE Opacity");
        var t0 = comp.time + (i * delay);
        var finalV = 100;
        var overV = 100 + amount;
        var underV = 100 - (amount * 0.25);

        try { scale.expression = ""; } catch(e){}

        if(type === "bounce"){
            scale.setValueAtTime(t0, mtScaleValue(scale, 0));
            scale.setValueAtTime(t0 + duration * 0.62, mtScaleValue(scale, overV));
            scale.setValueAtTime(t0 + duration, mtScaleValue(scale, finalV));
        } else if(type === "smallbounce"){
            scale.setValueAtTime(t0, mtScaleValue(scale, 0));
            scale.setValueAtTime(t0 + duration * 0.65, mtScaleValue(scale, 108));
            scale.setValueAtTime(t0 + duration, mtScaleValue(scale, finalV));
        } else if(type === "elastic"){
            scale.setValueAtTime(t0, mtScaleValue(scale, 0));
            scale.setValueAtTime(t0 + duration * 0.45, mtScaleValue(scale, overV));
            scale.setValueAtTime(t0 + duration * 0.70, mtScaleValue(scale, underV));
            scale.setValueAtTime(t0 + duration, mtScaleValue(scale, finalV));
        } else {
            scale.setValueAtTime(t0, mtScaleValue(scale, 0));
            scale.setValueAtTime(t0 + duration * 0.55, mtScaleValue(scale, 112));
            scale.setValueAtTime(t0 + duration, mtScaleValue(scale, finalV));
        }

        opacity.setValueAtTime(t0, 0);
        opacity.setValueAtTime(t0 + 0.04, 100);

        var startK = scale.nearestKeyIndex(t0);
        for(var k=1; k<=scale.numKeys; k++){
            var kt = scale.keyTime(k);
            if(kt >= t0 - 0.001 && kt <= t0 + duration + 0.001){
                mtSetEase(scale, k, 75, 75);
            }
        }
    }

    app.endUndoGroup();
    return "Pop applied: " + type;
}

function sequenceLayers(offsetFrames, step){
    var comp = getComp(); if(!comp) return "No comp";
    if(comp.selectedLayers.length === 0){ alert("Select layers to sequence."); return "Select layers"; }

    offsetFrames = parseFloat(offsetFrames); step = parseFloat(step);
    if(isNaN(offsetFrames)) offsetFrames = 3;
    if(isNaN(step)) step = 1;

    var selected = comp.selectedLayers;
    var offset = offsetFrames * comp.frameDuration;

    app.beginUndoGroup("Sequence Layers");
    for(var i=0; i<selected.length; i++){
        selected[i].startTime += i * offset * step;
    }
    app.endUndoGroup();
    return "Sequenced";
}

function extractSelected(){
    var comp = getComp(); if(!comp) return "No comp";
    if(comp.selectedLayers.length === 0){ alert("Select layers first."); return "Select layers"; }
    var selected = comp.selectedLayers;
    app.beginUndoGroup("Extract Selected");
    for(var i=0; i<selected.length; i++) selected[i].duplicate();
    app.endUndoGroup();
    return "Duplicated selected layers";
}

function precomposeSelected(){
    var comp = getComp(); if(!comp) return "No comp";
    if(comp.selectedLayers.length === 0){ alert("Select layers to merge/precompose."); return "Select layers"; }

    var indices = [];
    var selected = comp.selectedLayers;
    for(var i=0; i<selected.length; i++) indices.push(selected[i].index);

    app.beginUndoGroup("Merge Precompose");
    comp.layers.precompose(indices, "Merged Motion Tools", true);
    app.endUndoGroup();
    return "Merged / precomposed";
}

function addNullToSelected(){
    var comp = getComp(); if(!comp) return "No comp";
    var selected = comp.selectedLayers;
    app.beginUndoGroup("Add Null");
    var nul = comp.layers.addNull();
    nul.name = "Motion Tools Null";
    for(var i=0; i<selected.length; i++){
        if(selected[i] !== nul) selected[i].parent = nul;
    }
    app.endUndoGroup();
    return "Null added";
}

function convertToShape(){
    app.beginUndoGroup("Convert To Shape");
    try {
        app.executeCommand(app.findMenuCommandId("Create Shapes from Vector Layer"));
        app.endUndoGroup();
        return "Converted to shape";
    } catch(e) {
        app.endUndoGroup();
        alert("Select an Illustrator/vector layer first.");
        return "Could not convert";
    }
}

function removeArtboard(){
    var comp = getComp(); if(!comp) return "No comp";
    if(comp.selectedLayers.length === 0){ alert("Select layer/artboard first."); return "Select layers"; }
    app.beginUndoGroup("Remove Artboard");
    for(var i=0; i<comp.selectedLayers.length; i++) comp.selectedLayers[i].enabled = false;
    app.endUndoGroup();
    return "Hidden selected layer";
}

function addDustTexture(){
    var comp = getComp(); if(!comp) return "No comp";
    app.beginUndoGroup("Add Dust Texture");

    var solid = comp.layers.addSolid([0.5,0.5,0.5], "Dust Texture", comp.width, comp.height, comp.pixelAspect, comp.duration);
    solid.adjustmentLayer = true;
    try { solid.blendingMode = BlendingMode.SCREEN; } catch(e){}
    solid.property("ADBE Transform Group").property("ADBE Opacity").setValue(18);

    try {
        var noise = solid.property("ADBE Effect Parade").addProperty("ADBE Noise");
        noise.property("ADBE Noise-0001").setValue(22);
        noise.property("ADBE Noise-0002").setValue(false);
    } catch(e){}

    app.endUndoGroup();
    return "Dust texture added";
}

function addNoiseOverlay(){
    var comp = getComp(); if(!comp) return "No comp";
    app.beginUndoGroup("Add Noise Overlay");

    var solid = comp.layers.addSolid([0.5,0.5,0.5], "Noise Overlay", comp.width, comp.height, comp.pixelAspect, comp.duration);
    solid.adjustmentLayer = true;
    try { solid.blendingMode = BlendingMode.OVERLAY; } catch(e){}
    solid.property("ADBE Transform Group").property("ADBE Opacity").setValue(12);

    try {
        var noise = solid.property("ADBE Effect Parade").addProperty("ADBE Noise");
        noise.property("ADBE Noise-0001").setValue(12);
        noise.property("ADBE Noise-0002").setValue(false);
    } catch(e){}

    app.endUndoGroup();
    return "Noise overlay added";
}

function addGradientBG(){
    var comp = getComp(); if(!comp) return "No comp";
    app.beginUndoGroup("Add Gradient BG");

    var solid = comp.layers.addSolid([0.05,0.04,0.09], "Gradient Background", comp.width, comp.height, comp.pixelAspect, comp.duration);
    solid.moveToEnd();

    try {
        var ramp = solid.property("ADBE Effect Parade").addProperty("ADBE Ramp");
        ramp.property("ADBE Ramp-0001").setValue([comp.width*0.15, comp.height*0.15]);
        ramp.property("ADBE Ramp-0002").setValue([comp.width*0.9, comp.height*0.9]);
        ramp.property("ADBE Ramp-0003").setValue([0.52,0.35,1.0]);
        ramp.property("ADBE Ramp-0004").setValue([0.02,0.02,0.04]);
    } catch(e){}

    app.endUndoGroup();
    return "Gradient background added";
}

function addGradientOverlay(){
    var comp = getComp(); if(!comp) return "No comp";
    app.beginUndoGroup("Add Gradient Overlay");

    var solid = comp.layers.addSolid([1,1,1], "Gradient Overlay", comp.width, comp.height, comp.pixelAspect, comp.duration);
    try { solid.blendingMode = BlendingMode.SOFT_LIGHT; } catch(e){}
    solid.property("ADBE Transform Group").property("ADBE Opacity").setValue(35);

    try {
        var ramp = solid.property("ADBE Effect Parade").addProperty("ADBE Ramp");
        ramp.property("ADBE Ramp-0001").setValue([0, 0]);
        ramp.property("ADBE Ramp-0002").setValue([comp.width, comp.height]);
        ramp.property("ADBE Ramp-0003").setValue([0.6,0.35,1.0]);
        ramp.property("ADBE Ramp-0004").setValue([0.1,0.6,1.0]);
    } catch(e){}

    app.endUndoGroup();
    return "Gradient overlay added";
}
