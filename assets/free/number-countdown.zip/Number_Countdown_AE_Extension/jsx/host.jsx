function numberCountdown_getComp(duration){
    var comp = app.project.activeItem;
    if(!(comp && comp instanceof CompItem)){
        if(!app.project) app.newProject();
        comp = app.project.items.addComp('Countdown_Comp',1920,1080,1,duration+1,30);
    }
    if(comp.duration < duration+0.5) comp.duration = duration+0.5;
    return comp;
}
function numberCountdown_create(startNum,endNum,dur,fontSize,decimals,suffix,style){
    app.beginUndoGroup('Create Number Countdown');
    try{
        startNum = Number(startNum); endNum = Number(endNum); dur = Math.max(0.1,Number(dur)); fontSize = Number(fontSize); decimals = Math.max(0,Math.min(3,Number(decimals)));
        var comp = numberCountdown_getComp(dur);
        var txt = comp.layers.addText('0');
        txt.name = 'Animated Number Countdown';
        txt.startTime = 0; txt.outPoint = dur;
        txt.property('Position').setValue([comp.width/2, comp.height/2]);
        var textProp = txt.property('Source Text');
        var doc = textProp.value;
        doc.fontSize = fontSize;
        doc.justification = ParagraphJustification.CENTER_JUSTIFY;
        doc.fillColor = [1,1,1];
        doc.applyFill = true;
        textProp.setValue(doc);
        var slider = txt.property('Effects').addProperty('ADBE Slider Control');
        slider.name = 'Countdown Number';
        var sprop = slider.property('Slider');
        sprop.setValueAtTime(0,startNum);
        sprop.setValueAtTime(dur,endNum);
        try{sprop.setInterpolationTypeAtKey(1,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);sprop.setInterpolationTypeAtKey(2,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);}catch(e){}
        var expr = "var n = effect('Countdown Number')('Slider');\nvar d = "+decimals+";\nvar p = '"+suffix.replace(/'/g,"\\'")+"';\n(n).toFixed(d) + p;";
        textProp.expression = expr;
        if(style=='glow' || style=='ring' || style=='bounce'){
            var glow = txt.property('Effects').addProperty('ADBE Glow');
            glow.property('Glow Radius').setValue(45);
            glow.property('Glow Intensity').setValue(1.2);
        }
        if(style=='bounce' || style=='ring'){
            txt.property('Scale').expression = "freq=2.8; amp=18; decay=4;\nt=0;\nif(numKeys>0){t=time-inPoint;}\nbase=100;\nw=Math.sin(t*freq*Math.PI*2)*amp/Math.exp(decay*t);\n[base+w,base+w];";
        }
        if(style=='ring'){
            var shape = comp.layers.addShape();
            shape.name = 'Countdown Progress Ring';
            shape.moveAfter(txt);
            shape.property('Transform').property('Position').setValue([comp.width/2,comp.height/2]);
            var contents = shape.property('Contents');
            var ellipse = contents.addProperty('ADBE Vector Shape - Ellipse');
            ellipse.property('Size').setValue([fontSize*2.2,fontSize*2.2]);
            var stroke = contents.addProperty('ADBE Vector Graphic - Stroke');
            stroke.property('Color').setValue([0.35,0.45,1]);
            stroke.property('Stroke Width').setValue(12);
            var trim = contents.addProperty('ADBE Vector Filter - Trim');
            trim.property('End').setValueAtTime(0,100);
            trim.property('End').setValueAtTime(dur,0);
            shape.property('Transform').property('Rotation').setValue(-90);
        }
        app.endUndoGroup();
        return '<span class="ok">Countdown created successfully.</span>';
    }catch(err){app.endUndoGroup(); return '<span class="err">Error: '+err.toString()+'</span>';}
}
